clear all
close all
clc

H0 = SE3;
H1 = SE3(rotz(pi), [3 0 0]);
H2 = SE3(roty(pi/2), [0 0 0]);
H3 = SE3(rotx(150*pi/180), [-5 0 0]);

H20 = H1 * H2;
H30 = H20 * H3;

x = [0 3 3 0 0 0 0 0 0 3];
y = [0 0 0 0 0 5 5 0 5 0];
z = [0 0 5 5 0 0 5 5 5 5];

plot3(x, y, z, 'LineWidth', 1.5); 
axis([-1 4 -1 6 -1 6]); 
grid on;
hold on;

trplot(H0, 'rgb', 'axis', [-1 4 -1 6 -1 6]);

pause;
tranimate(H0, H1, 'rgb', 'axis', [-1 4 -1 6 -1 6]);

pause;
tranimate(H1, H20, 'rgb', 'axis', [-1 4 -1 6 -1 6]);

pause;
tranimate(H20, H30, 'rgb', 'axis', [-1 4 -1 6 -1 6]);

disp('Matriz de transformación homogénea global T');
disp(H30);
