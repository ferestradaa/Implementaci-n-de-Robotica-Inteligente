clear all
close all
clc

H0=SE3([0 0 6]);
primera_rotacion = roty(pi/2)*rotx(pi/2); %se multiplican las rotaciones para ahorrar pasos y realizar un solo movimiento para la animacion
H1=SE3(primera_rotacion, [0 0 6]); 
H2=SE3(rotx(-pi/2), [0 0 0]); %se realiza una rotacion en x sin traslacion
H3=SE3([3 0 0]); %manteniendo la orientacion, se traslada 3 en z
H4=SE3(rotz(-pi/2), [3 0 0]); %se rotan -90° en z mientras baja 3 unidades mas
H5=SE3(rotx(pi/2), [0 0 0]); % finalmente rota en x 90 sin trasladarse


H20= H1*H2;
H30= H20*H3; %multiplicacion de matrices homogeneas sucesivas
H40= H30*H4;
H50= H40*H5;


%Ubicacion de puntos para estructura de eje
x=[3 0 0];
y=[0 0 0];
z=[6 6 0];

plot3(x, y, z,'LineWidth', 1.5); axis([-1 7 -1 7 -1 7]); grid on;
hold on;

trplot(H0,'rgb','axis', [-1 7 -1 7 -1 7]);
 pause;
  tranimate(H0, H1,'rgb','axis', [-1 7 -1 7 -1 7]);

 pause;
 tranimate(H1, H20,'rgb','axis', [-1 7 -1 7 -1 7]);

 pause;
  tranimate(H20, H30,'rgb','axis', [-1 7 -1 7 -1 7]);

 pause;
  tranimate(H30, H40,'rgb','axis', [-1 7 -1 7 -1 7]);

 pause;
  tranimate(H40, H50,'rgb','axis', [-1 7 -1 7 -1 7])
  disp('Matriz de transformación homogénea global T')
  disp(H50)

