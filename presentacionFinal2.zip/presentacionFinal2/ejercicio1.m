clear all
close all
clc

%Se obtienen las matrices de transformación homogénea para cada segmento
%del movimiento

H0 =SE3; % Punto origen
H1=SE3(rotx(pi/2), [0 0 4]); %simultaneamente se hace una rotacion en x de 90° con una traslacion en z
H2=SE3([1.33 0 0]); % primera traslación en x
H3=SE3([1.33 0 0]); % segunda Traslación en x
H4=SE3([1.33 0 0]); % tercera Traslación en x

%para obtener la matriz de transformacion global se multiplican las
%matrices individuales sucesivamente
H20= H1*H2;
H30= H20*H3; %Matriz de transformación homogenea global de 3 a 0 
H40= H30*H4;

%Coordenadas de la estructura de translación y rotación
x=[4 0 0]; %el primer punto se grafica en (4,0,4) luego (0,0,4) y (0,0,0)
y=[0 0 0];
z=[4 4 0];

plot3(x, y, z,'LineWidth', 1.5); axis([-1 5 -1 5 -1 5]); grid on;
hold on;

%se realiza la animacion para cada una de las transformaciones
trplot(H0,'rgb','axis', [-1 5 -1 5 -1 5]);

 pause;
  tranimate(H0, H1,'rgb','axis', [-1 5 -1 5 -1 5]);

 pause;
 tranimate(H1, H20,'rgb','axis', [-1 5 -1 5 -1 5]);

 pause;
  tranimate(H20, H30,'rgb','axis', [-1 5 -1 5 -1 5]);
  disp(H30)

 pause;
  tranimate(H30, H40,'rgb','axis', [-1 5 -1 5 -1 5])
  disp('Matriz de transformación homogénea global T')
  disp(H40) %se imprime la matriz de transformacion global del sistema