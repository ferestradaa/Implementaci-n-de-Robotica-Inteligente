clear all
close all
clc

H0 = SE3([4.5 3 10.5]);
H1 = SE3(roty(-3.07179) * rotz(-1.6406) * rotx(-0.3229), [4.5 3 10.5]);  
H2 = SE3(rotx(-1.117) * roty(1.6406), [0 0 0]);  
H3 = SE3(rotz(-2.0364), [0 0 0]);  
H4 = SE3(rotx(1.501), [0 0 0]);  
H5 = SE3([4.5 0 0]); %traslacion en x (se produce un error dado que esta en diagonal)

rotarz = rotz(-0.4712);  

H6 = SE3((rotz(1.501) * roty(1.6406)) * rotarz, [6.882 0 0]);  % Ajustes incluidos directamente
H7 = SE3(rotz(1.6406) * rotx(1.501), [0 0 0]);  % Ajustes incluidos directamente
H8 = SE3([0 0 4.242]); %traslacion final

H20 = H1 * H2;
H30 = H20 * H3;
H40 = H30 * H4;
H50 = H40 * H5;
H60 = H50 * H6;
H70 = H60 * H7;
H80 = H70 * H8;

x = [3 0 4.5];
y = [3 3 3];
z = [-3 0 10.5];

axis_limits = [-1.5 11.25 -1.5 11.25 -4.5 14.25];

plot3(x, y, z, 'LineWidth', 1.5);
axis(axis_limits);
grid on;
hold on;

trplot(H0, 'rgb', 'axis', axis_limits);

pause;
tranimate(H0, H1, 'rgb', 'axis', axis_limits);

pause;
tranimate(H1, H20, 'rgb', 'axis', axis_limits);

pause;
tranimate(H20, H30, 'rgb', 'axis', axis_limits);

pause;
tranimate(H30, H40, 'rgb', 'axis', axis_limits);

pause;
tranimate(H40, H50, 'rgb', 'axis', axis_limits);

pause;
tranimate(H50, H60, 'rgb', 'axis', axis_limits);

pause;
tranimate(H60, H70, 'rgb', 'axis', axis_limits);

pause;
tranimate(H70, H80, 'rgb', 'axis', axis_limits);

disp('Matriz de transformación homogénea global T');
disp(H80);
