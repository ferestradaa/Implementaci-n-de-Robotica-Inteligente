clear all
close all
clc

syms thx1(t) thy1(t) thz1(t) a1 l1 t
syms thz2(t) a2 l2
syms thy3(t) thz3(t) a3 l3

jointTypes = [0 0 0];

theta = [thx1, thy3, thz2];

thetaDot = diff(theta, t);

DOF = length(jointTypes);

R1x = [1      0               0;
            0 cos(thx1) -sin(thx1);
            0 sin(thx1) cos(thx1)];

R1y = [cos(thy1)   0  sin(thy1);
        0            1           0;
        -sin(thy1)  0  cos(thy1)];

R1z = [cos(thz1)  -sin(thz1)  0;
        sin(thz1)   cos(thz1)  0;
        0               0        1];

R(:,:,1) = R1z * R1y * R1x;

P(:,:,1) = [l1*cos(thx1); l1*sin(thy1); 0];

R2 = [cos(thz2) -sin(thz2) 0;
        sin(thz2) cos(thz2) 0;
        0 0 1];

R(:,:,2) = R2;

P(:,:,2) = [l2*cos(thz2); l2*cos(thz2); 0];

R3y = [cos(thy3) 0 sin(thy3);
                  0    1     0;
             -sin(thy3) 0 cos(thy3)];

R3z = [cos(thz3) -sin(thz3) 0;
            sin(thz3) cos(thz3) 0;
                              0 0 1];

R(:,:,3) = R3y * R3z;
P(:,:,3) = [l3*cos(thy3); l3*sin(thz3); 0];

zeroVec = zeros(1, 3);

A(:,:,DOF)=simplify([R(:,:,DOF) P(:,:,DOF); zeroVec 1]);
T(:,:,DOF)=simplify([R(:,:,DOF) P(:,:,DOF); zeroVec 1]);
PO(:,:,DOF)= P(:,:,DOF); 
RO(:,:,DOF)= R(:,:,DOF); 

for i = 1:DOF
    i_str = num2str(i);
    A(:,:,i) = simplify([R(:,:,i) P(:,:,i); zeroVec 1]);

    if i == 1
        T(:,:,i) = A(:,:,i);
    else
        T(:,:,i) = T(:,:,i-1) * A(:,:,i);
    end

    T(:,:,i) = simplify(T(:,:,i));
    disp(['Matriz de Transformación global T', i_str]);
    pretty(T(:,:,i))

    RO(:,:,i) = T(1:3, 1:3, i);
    PO(:,:,i) = T(1:3, 4, i);
end

Jv(:,DOF) = PO(:,:,DOF);
Jw(:,DOF) = PO(:,:,DOF);

for k = 1:DOF
    if jointTypes(k) == 0
        if k == 1
            Jv(:,k) = cross([0,0,1], PO(:,:,DOF));
            Jw(:,k) = [0,0,1];
        else
            Jv(:,k) = cross(RO(:,3,k-1), PO(:,:,DOF) - PO(:,:,k-1));
            Jw(:,k) = RO(:,3,k-1);
        end
    else
        if k == 1
            Jv(:,k) = [0,0,1];
        else
            Jv(:,k) = RO(:,3,k-1);
        end
        Jw(:,k) = [0,0,0];
    end
end

Jv = simplify(Jv);
Jw = simplify(Jw);

disp('Jacobiano lineal obtenido de forma analítica');
pretty(Jv);
disp('Jacobiano ángular obtenido de forma analítica');
pretty(Jw);

disp('Velocidad lineal obtenida mediante el Jacobiano lineal');
V = simplify(Jv * thetaDot');
pretty(V);
disp('Velocidad angular obtenida mediante el Jacobiano angular');
W = simplify(Jw * thetaDot');
pretty(W);
