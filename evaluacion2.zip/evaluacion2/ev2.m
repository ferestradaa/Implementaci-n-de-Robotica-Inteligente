
%% EXAMPLE: Differential drive vehicle following waypoints using the 
% Pure Pursuit algorithm
%
% Copyright 2018-2019 The MathWorks, Inc.

%% Define Vehicle
R = 0.1;                % Wheel radius [m]
L = 0.5;                % Wheelbase [m]
dd = DifferentialDrive(R,L);

%% Simulation parameters
sampleTime = 0.05;               % Sample time [s]
tVec = 0:sampleTime:320;         % Time array
initPose = [1;0;0];             % Initial pose (x y theta)
pose = zeros(3,numel(tVec));    % Pose matrix
pose(:,1) = initPose;
waypoints = [1,0; 1,3; 3,3; 1,3; 1,2; 3,2; 1,2; 1,0;
            6,0; 4,0; 4,1.5; 6,1.5; 4,1.5; 4,3; 6,3; 4,3; 4,0; 
            7,0; 7,2; 9,0; 7,2; 9,2; 9,3; 7,3; 7,0; 
            10,0; 10,3; 12,0; 12,3; 12,0; 
            13,0; 13,3; 15,3; 15,1.5; 13,1.5; 15,1.5; 15,0; 
            16,0; 16,3; 18,0; 18,3; 18,0; 
            19,0; 19,3; 21,3; 21.5,2; 21.5,1; 21,0; 19,0; 21,0; 
            24,0; 25,0; 26,1; 26,2; 25,3; 24,3; 23,2; 23,1; 24,0;
             ];


% Create visualizer
viz = Visualizer2D;
viz.hasWaypoints = true;

%% Pure Pursuit Controller
controller = controllerPurePursuit;
controller.Waypoints = waypoints;
controller.LookaheadDistance = 0.14; 
controller.DesiredLinearVelocity = 0.38;
controller.MaxAngularVelocity = 8.3;

%% Simulation loop
close all
r = rateControl(1/sampleTime);
for idx = 2:numel(tVec) 
    % Run the Pure Pursuit controller and convert output to wheel speeds
    [vRef,wRef] = controller(pose(:,idx-1));
    [wL,wR] = inverseKinematics(dd,vRef,wRef);
 
    
    % Compute the velocities
    [v,w] = forwardKinematics(dd,wL,wR);
    velB = [v;0;w]; % Body velocities [vx;vy;w]
    vel = bodyToWorld(velB,pose(:,idx-1));  % Convert from body to world
    
    % Perform forward discrete integration step
    pose(:,idx) = pose(:,idx-1) + vel*sampleTime; 
    
    % Update visualization
    viz(pose(:,idx),waypoints);
    waitfor(r);
    
end